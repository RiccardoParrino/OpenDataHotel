python "./Hotel/FromCsvToJson.py"
echo "ciao"
python "./Hotel/FromFlatHotelMilano2018ToFinalHotelMilano2018.py" 

python "./Hotel/aggiustaDs48HotelFile.py" 

python "./Hotel/FromGeoJsonToFlatGeoJsonMilanHotel.py" 

python "./Hotel/FromFlatMilanHotelToFinalFlatMilanHotel.py" 

python "./Hotel/createFinalHotel.py" 

python "./Hotel/clean.py"

python "./Monument/FromCsvToJson.py" 

python "./Monument/FromCleanedMonumentToFinalFlatMonument.py"

python "./Monument/clean.py"

python "./CarRental/FromCarRentalToFlatCarRental.py"

python "./CarRental/clean.py"

python "./BikeRental/FromBikeRentalToFlatBikeRental.py"

python "./BikeRental/clean.py"

python "./CarSharing/FromCarSharingToFlatCarSharing.py"

python "./CarSharing/clean.py"

python "./RailwayStation/FromRailwayStationToFinalRailwayStation.py"

python "./RailwayStation/clean.py"

python "./SubwayStation/FromeSubwayStationToFinalSubwayStation.py"

python "./SubwayStation/clean.py"

python "./Park/FromParkPublicToFinalParkPublic.py"

python "./Park/clean.py"

python "./Bus/FromBusStationToFlatBusStation.py"

python "./Bus/clean.py"

python "./Pub/FromPubToFlatPub.py"

python "./Pub/clean.py"

python "./FastFood/FromFastFoodToFlatFastFood.py"

python "./FastFood/clean.py"

python "./Parking/FromParkingToFlatParking.py"

python "./Parking/clean.py"

python "./Restaurant/FromRestaurantToFlatRestaurant.py"

python "./Restaurant/clean.py"

python "./Bar/FromBarToFlatBar.py"

python "./Bar/clean.py"

python "./Programmi Python Creazione Triple/ParkingTriple.py"

python "./Programmi Python Creazione Triple/PubTriple.py"

python "./Programmi Python Creazione Triple/FastFoodTriple.py"

python "./Programmi Python Creazione Triple/ParkPublicTriple.py"

python "./Programmi Python Creazione Triple/CarSharingTriple.py"

python "./Programmi Python Creazione Triple/CarRentalTriple.py"

python "./Programmi Python Creazione Triple/BikeRentalTriple.py"

python "./Programmi Python Creazione Triple/HotelTriple.py"

python "./Programmi Python Creazione Triple/RailwayTriple.py"

python "./Programmi Python Creazione Triple/SubwayTriple.py"

python "./Programmi Python Creazione Triple/MonumentTriple.py"

python "./Programmi Python Creazione Triple/RestaurantTriple.py"

python "./Programmi Python Creazione Triple/BarTriple.py"

python "./Programmi Python Creazione Triple/BusTriple.py"

python "./Programmi Python Creazione Triple/hasClose.py"

python "./Programmi Python Creazione Triple/hasValutation.py"

python "./Programmi Python Creazione Triple/AddValutation.py"