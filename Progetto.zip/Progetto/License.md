All files are distributed under a Creative Commons Attribution 4.0 license.

References: 

OpenStreetMap contributors, FastFood Dataset, CarSharing Dataset, Bar Dataset, Restaurant Dataset, Parking Dataset, BikeRental Dataset, CarRental Dataset, Pub Dataset, MilanHotel Dataset, "https://www.openstreetmap.org" ;

Dati Comune Milano, SubwayStation Dataset, "http://dati.comune.milano.it/dataset/b7344a8f-0ef5-424b-a902-f7f06e32dd67/resource/dd6a770a-b321-44f0-b58c-9725d84409bb/download/tpl_metrofermate.geojson"

Dati Comune Milano, Bus Dataset, "http://dati.comune.milano.it/dataset/ac494f5d-acd3-4fd3-8cfc-ed24f5c3d923/resource/7d21bd77-3ad1-4235-9a40-8a8cdfeb65a0"

Dati Comune Milano, RailwayStation Dataset, "http://dati.comune.milano.it/dataset/802a1d1f-4203-44c9-b9f5-dd8aa1f6bc3c/resource/7a07abfb-6a0d-458d-9a91-e6eb5b1ba703"

Dati Comune Milano, RailwayStation Dataset, "http://dati.comune.milano.it/dataset/802a1d1f-4203-44c9-b9f5-dd8aa1f6bc3c/resource/7a07abfb-6a0d-458d-9a91-e6eb5b1ba703"

Dati Comune Milano, hotel_Milano_2018.csv, "https://dati.lombardia.it/dataset/2p47-g7cn"

Dati Comune Milano, ds48_turismotempolibero_strutture-ricettive-alberghiere_2015.json, "http://dati.comune.milano.it/dataset/fd725151-da06-4973-b4a9-6c41717e7db0"

Dati Comune Milano, Park Dataset, "http://dati.comune.milano.it/dataset/8920bbea-fe1a-4061-8c6e-0746d95316c1/resource/7cba11e7-c236-49a7-aef4-4db6329eec5d"

Dati Comune Milano, Monument Dataset, "https://www.dati.lombardia.it/Cultura/Beni-culturali-Bella-Lombardia/4mr7-hfsh"
